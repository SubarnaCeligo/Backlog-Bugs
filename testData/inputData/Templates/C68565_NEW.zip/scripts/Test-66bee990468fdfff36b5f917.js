/*
* filterFunction stub:
*
* The name of the function can be changed to anything you like.
*
* The function will be passed one 'options' argument that has the following fields:
*   'record' - object {} or array [] depending on the data source.
*   'pageIndex' - 0 based. context is the batch export currently running.
*   'lastExportDateTime' - delta exports only.
*   'currentExportDateTime' - delta exports only.
*   'settings' - all custom settings in scope for the filter currently running.
* The function needs to return true or false.  i.e. true indicates the record should be processed.
* Throwing an exception will return an error for the record.
*/
function test (options) {
  return true
}