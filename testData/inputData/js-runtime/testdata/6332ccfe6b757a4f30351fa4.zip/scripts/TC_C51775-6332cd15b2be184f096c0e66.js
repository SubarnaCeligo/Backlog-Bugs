import sjcl from 'sjcl@1.8.0'
import dayjs from 'dayjs'
import api from 'integrator-api';
function preMap (options) {
	var a = dayjs("2018-08-08")
	console.log(a);
  var encrypt = sjcl.encrypt("password", "data");
  let decript = sjcl.decrypt("password", encrypt);
  console.log(decript);
  return options.data.map((d) => {
    d.newDate = a;
    d.decrypt = decript
    return {
      data: d
    }
  })
}